package com.Booking.controlller;

import java.io.IOException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.Booking.entity.Branch;
import com.Booking.service.BranchService;

import jakarta.servlet.http.HttpServletResponse;

@RestController
@RequestMapping(value="/api/branches")
public class BranchController {
	
	 private static final Logger logger = LoggerFactory.getLogger(BranchController.class);
	
	@Autowired
    private BranchService branchService;
	
	@GetMapping
    public ResponseEntity<Page<Branch>> getBranches(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "id") String sortBy) {
        try {
            Page<Branch> branches = branchService.getBranches(page, size, sortBy);
            return new ResponseEntity<>(branches, HttpStatus.OK);
        } catch (Exception e) {
            logger.error("Error fetching branches", e);
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping
    public ResponseEntity<Branch> createBranch(@RequestBody @Validated Branch branch) {
        Branch createdBranch = branchService.createBranch(branch);
        return new ResponseEntity<>(createdBranch, HttpStatus.CREATED);
    }

   @PutMapping("/{id}")
    public ResponseEntity<Branch> updateBranch(@PathVariable Long id, @RequestBody @Validated Branch branch) {
        Branch updatedBranch = branchService.updateBranch(id, branch);
        return new ResponseEntity<>(updatedBranch, HttpStatus.OK);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteBranch(@PathVariable Long id) {
        branchService.deleteBranch(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }

    @PostMapping("/import")
    public ResponseEntity<Void> importBranches(@RequestParam("file") MultipartFile file) {
        branchService.importBranches(file);
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @GetMapping("/export")
    public void exportBranches(HttpServletResponse response) throws IOException {
        response.setContentType("application/vnd.ms-excel");
        response.setHeader("Content-Disposition", "attachment; filename=branches.xlsx");
        branchService.exportBranches(response.getOutputStream());
    }

}
