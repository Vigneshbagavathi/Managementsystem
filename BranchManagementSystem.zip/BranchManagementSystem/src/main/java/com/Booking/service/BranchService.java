package com.Booking.service;

import java.io.IOException;
import java.io.OutputStream;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.Booking.entity.Branch;
import com.Booking.exception.ResourceNotFoundException;
import com.Booking.repository.BranchRepository;

@Service
public class BranchService {

    @Autowired
    private BranchRepository branchRepository;

    public Branch createBranch(Branch branch) {
        return branchRepository.save(branch);
    }

    public Page<Branch> getBranches(int page, int size, String sortBy) {
        return branchRepository.findAll(PageRequest.of(page, size, Sort.by(sortBy)));
    }

    public Branch updateBranch(Long id, Branch branch) {
        Branch existingBranch = branchRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Branch not found"));
        existingBranch.setName(branch.getName());
        existingBranch.setAddress(branch.getAddress());
        existingBranch.setManager(branch.getManager());
        return branchRepository.save(existingBranch);
    }

    public void deleteBranch(Long id) {
        branchRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Branch not found"));
        branchRepository.deleteById(id);
    }

    public void importBranches(MultipartFile file) {
        // Logic for Excel file parsing and saving to database
    }

    public void exportBranches(OutputStream outputStream) throws IOException {
        // Logic for exporting data to Excel
    }
}
